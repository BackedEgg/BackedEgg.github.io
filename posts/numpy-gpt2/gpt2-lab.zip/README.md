# NumPy로 GPT-2 small 따라가기

본문 실험의 순전파 계산은 `gpt2_numpy.py`에서 NumPy로 구현했습니다. PyTorch와
Transformers는 **기준 출력 검증용**으로만 사용합니다. 공개 모델 가중치는 ZIP에 넣지
않았습니다. `download_model.py`가 지정한 Hugging Face 리비전을 내려받고 SHA-256을
확인합니다.

Windows PowerShell에서 Python 3.12를 설치한 뒤 실행합니다. `py -3.12 --version`으로 설치 여부를 확인할 수 있습니다.

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe download_model.py
.\.venv\Scripts\python.exe parity_probe.py
.\.venv\Scripts\python.exe experiments.py
```

결과 파일:

- `parity_results.json`: 전체 위치·전체 어휘 logits의 최대/평균 절댓값 차이
- `experiment_results.json`: 토큰화, BPE, 어텐션, 샘플링, 구성 요소 제거 실험
- `figures/attention_layer1_head1.png`: 어텐션 맵

`experiment_results.json`의 구성 요소 제거 실험은 **이미 학습된 모델의 연산을
바꾼 결과**입니다. 해당 요소 없이 처음부터 학습한 모델의 성능을 뜻하지 않습니다.
