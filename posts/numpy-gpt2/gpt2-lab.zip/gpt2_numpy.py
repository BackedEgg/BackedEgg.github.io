"""GPT-2 small inference with NumPy operations and public safetensors weights.

Only weight loading uses safetensors. The forward pass uses NumPy, not PyTorch.
The optional ablations perturb a *pretrained* model; they are not retraining runs.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from safetensors.numpy import load_file


def softmax(x: np.ndarray, axis: int = -1) -> np.ndarray:
    x = x - np.max(x, axis=axis, keepdims=True)
    e = np.exp(x)
    return e / np.sum(e, axis=axis, keepdims=True)


def layer_norm(x: np.ndarray, weight: np.ndarray, bias: np.ndarray,
               eps: float = 1e-5) -> np.ndarray:
    mean = np.mean(x, axis=-1, keepdims=True)
    var = np.mean((x - mean) ** 2, axis=-1, keepdims=True)
    return (x - mean) / np.sqrt(var + eps) * weight + bias


def gelu_new(x: np.ndarray) -> np.ndarray:
    """Hugging Face GPT-2's tanh approximation to GELU."""
    return 0.5 * x * (1.0 + np.tanh(np.sqrt(2.0 / np.pi) * (x + 0.044715 * x ** 3)))


class GPT2NumPy:
    def __init__(self, model_dir: str | Path):
        model_dir = Path(model_dir)
        self.config = json.loads((model_dir / "config.json").read_text(encoding="utf-8"))
        self.w = load_file(model_dir / "model.safetensors")
        self.n_head = int(self.config["n_head"])
        self.n_embd = int(self.config["n_embd"])
        self.head_dim = self.n_embd // self.n_head
        if self.n_embd % self.n_head:
            raise ValueError("embedding dimension must be divisible by head count")

    def forward(self, token_ids: list[int], *, attention_layer: int | None = None,
                attention_head: int = 0, no_scale: bool = False,
                no_mask: bool = False, no_residual: bool = False
                ) -> tuple[np.ndarray, np.ndarray | None]:
        """Return logits [tokens, vocabulary] and optionally one attention map."""
        ids = np.asarray(token_ids, dtype=np.int64)
        if ids.ndim != 1 or len(ids) == 0:
            raise ValueError("token_ids must be a non-empty 1D sequence")
        t = len(ids)
        if t > int(self.config["n_positions"]):
            raise ValueError("prompt exceeds GPT-2 position-embedding length")
        w = self.w
        h = w["wte.weight"][ids] + w["wpe.weight"][np.arange(t)]
        chosen_attention = None
        causal = np.tril(np.ones((t, t), dtype=bool))

        for i in range(int(self.config["n_layer"])):
            p = f"h.{i}."
            residual = h
            x = layer_norm(h, w[p + "ln_1.weight"], w[p + "ln_1.bias"])

            # Hugging Face Conv1D stores weights as [input, output].
            qkv = x @ w[p + "attn.c_attn.weight"] + w[p + "attn.c_attn.bias"]
            q, k, v = np.split(qkv, 3, axis=-1)
            q, k, v = [a.reshape(t, self.n_head, self.head_dim).transpose(1, 0, 2)
                       for a in (q, k, v)]
            scores = q @ k.transpose(0, 2, 1)
            if not no_scale:
                scores = scores / np.float32(np.sqrt(self.head_dim))
            if not no_mask:
                scores = np.where(causal[None, :, :], scores, np.finfo(scores.dtype).min)
            attn = softmax(scores)
            if attention_layer == i:
                chosen_attention = attn[attention_head].copy()
            context = attn @ v
            context = context.transpose(1, 0, 2).reshape(t, self.n_embd)
            a = context @ w[p + "attn.c_proj.weight"] + w[p + "attn.c_proj.bias"]
            h = a if no_residual else residual + a

            residual = h
            x = layer_norm(h, w[p + "ln_2.weight"], w[p + "ln_2.bias"])
            x = x @ w[p + "mlp.c_fc.weight"] + w[p + "mlp.c_fc.bias"]
            x = gelu_new(x)
            m = x @ w[p + "mlp.c_proj.weight"] + w[p + "mlp.c_proj.bias"]
            h = m if no_residual else residual + m

        h = layer_norm(h, w["ln_f.weight"], w["ln_f.bias"])
        # GPT-2 ties the output projection to the token-embedding matrix.
        logits = h @ w["wte.weight"].T
        return logits, chosen_attention


def sampling_distribution(logits: np.ndarray, *, temperature: float = 1.0,
                          top_k: int | None = None, top_p: float | None = None) -> np.ndarray:
    """Temperature, then optional top-k/top-p filtering, then normalization."""
    if temperature <= 0:
        raise ValueError("temperature must be positive; use argmax for greedy")
    z = np.asarray(logits, dtype=np.float64) / temperature
    if top_k is not None:
        if top_k < 1:
            raise ValueError("top_k must be positive")
        keep = np.argpartition(z, -min(top_k, len(z)))[-min(top_k, len(z)):]
        mask = np.ones(len(z), dtype=bool)
        mask[keep] = False
        z[mask] = -np.inf
    probs = softmax(z)
    if top_p is not None:
        if not 0 < top_p <= 1:
            raise ValueError("top_p must be in (0, 1]")
        order = np.argsort(probs)[::-1]
        keep_count = int(np.searchsorted(np.cumsum(probs[order]), top_p, side="left")) + 1
        mask = np.ones(len(z), dtype=bool)
        mask[order[:keep_count]] = False
        probs[mask] = 0
        probs /= probs.sum()
    return probs
