"""Compare the complete NumPy GPT-2 logits against Hugging Face locally."""

import json
from pathlib import Path

import numpy as np
import tiktoken
import torch
from transformers import GPT2LMHeadModel, GPT2TokenizerFast

from gpt2_numpy import GPT2NumPy


ROOT = Path(__file__).resolve().parent
MODEL = ROOT / "model"
PROMPTS = ["The capital of France is", "오늘의 날씨는"]


def main() -> None:
    torch.set_num_threads(4)
    enc = tiktoken.get_encoding("gpt2")
    tokenizer = GPT2TokenizerFast.from_pretrained(MODEL)
    reference = GPT2LMHeadModel.from_pretrained(MODEL, attn_implementation="eager")
    reference.eval()
    numpy_model = GPT2NumPy(MODEL)
    results = []
    for prompt in PROMPTS:
        ids = enc.encode(prompt)
        assert ids == tokenizer.encode(prompt, add_special_tokens=False), "tokenizers differ"
        with torch.inference_mode():
            hf_logits = reference(torch.tensor([ids]), use_cache=False).logits[0].numpy()
        np_logits, _ = numpy_model.forward(ids)
        error = np.abs(hf_logits - np_logits)
        assert np.allclose(hf_logits, np_logits, atol=2e-4, rtol=1e-5)
        assert int(np_logits[-1].argmax()) == int(hf_logits[-1].argmax())
        result = {
            "prompt": prompt,
            "token_ids": ids,
            "shape": list(np_logits.shape),
            "max_abs_error": float(error.max()),
            "mean_abs_error": float(error.mean()),
            "last_argmax_id_numpy": int(np_logits[-1].argmax()),
            "last_argmax_id_hf": int(hf_logits[-1].argmax()),
            "passed_atol_2e-4_rtol_1e-5": True,
        }
        results.append(result)
        print(json.dumps(result, ensure_ascii=False), flush=True)
    (ROOT / "parity_results.json").write_text(
        json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
