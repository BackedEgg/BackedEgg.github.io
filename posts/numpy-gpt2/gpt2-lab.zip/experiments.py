"""Reproducible GPT-2 NumPy tokenizer, attention, sampling, and ablation probes."""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import tiktoken
import torch
import transformers

from gpt2_numpy import GPT2NumPy, sampling_distribution
from download_model import sha256_file


ROOT = Path(__file__).resolve().parent
MODEL = ROOT / "model"
FIGURES = ROOT / "figures"
FIGURES.mkdir(exist_ok=True)
ENC = tiktoken.get_encoding("gpt2")


def toy_bpe(words: list[str], steps: int = 4) -> list[dict]:
    """Character-pair BPE for teaching; not GPT-2's byte-level tokenizer."""
    pieces = [list(word) for word in words]
    history = []
    for _ in range(steps):
        counts = Counter(pair for word in pieces for pair in zip(word, word[1:]))
        if not counts:
            break
        pair = sorted(counts, key=lambda item: (-counts[item], item))[0]
        merged = "".join(pair)
        updated = []
        for word in pieces:
            new_word, i = [], 0
            while i < len(word):
                if i + 1 < len(word) and (word[i], word[i + 1]) == pair:
                    new_word.append(merged)
                    i += 2
                else:
                    new_word.append(word[i])
                    i += 1
            updated.append(new_word)
        pieces = updated
        history.append({"pair": pair, "count": counts[pair], "pieces": [w.copy() for w in pieces]})
    return history


def token_text(token_id: int) -> str:
    return ENC.decode([token_id]).replace("\n", "\\n")


def entropy(probs: np.ndarray) -> float:
    nonzero = probs[probs > 0]
    return float(-(nonzero * np.log2(nonzero)).sum())


def summarize_sampling(logits: np.ndarray, **kwargs) -> dict:
    probs = sampling_distribution(logits, **kwargs)
    rng = np.random.default_rng(42)
    draws = rng.choice(len(probs), size=100, p=probs)
    sample_id = int(draws[0])
    top_ids = np.argsort(probs)[-5:][::-1]
    return {
        "settings": kwargs,
        "support_size": int(np.count_nonzero(probs)),
        "entropy_bits": entropy(probs),
        "sampled_id_seed42": sample_id,
        "sampled_text_seed42": token_text(sample_id),
        "distinct_ids_in_100_draws": len(set(map(int, draws))),
        "top5": [{"id": int(i), "text": token_text(int(i)), "p": float(probs[i])}
                 for i in top_ids],
    }


def main() -> None:
    model = GPT2NumPy(MODEL)
    samples = [
        {"ko": "나는 오늘 학교에 간다.", "en": "I go to school today."},
        {"ko": "고양이가 창문 옆에 앉아 있다.", "en": "A cat is sitting by the window."},
    ]
    tokenization = []
    for pair in samples:
        tokenization.append({
            language: {"text": pair[language], "ids": ENC.encode(pair[language]),
                       "count": len(ENC.encode(pair[language]))}
            for language in ("ko", "en")
        })

    attention_prompt = "The cat sat on the mat."
    attention_ids = ENC.encode(attention_prompt)
    _, attn = model.forward(attention_ids, attention_layer=0, attention_head=0)
    assert attn is not None
    fig, ax = plt.subplots(figsize=(7, 6))
    image = ax.imshow(attn, vmin=0, vmax=1, cmap="viridis")
    labels = [token_text(i) for i in attention_ids]
    ax.set_xticks(range(len(labels)), labels, rotation=45, ha="right")
    ax.set_yticks(range(len(labels)), labels)
    ax.set_xlabel("Key: tokens being read")
    ax.set_ylabel("Query: token doing the reading")
    ax.set_title("GPT-2 small: layer 1, head 1 (observed attention weights)")
    fig.colorbar(image, ax=ax, label="attention weight")
    fig.tight_layout()
    fig.savefig(FIGURES / "attention_layer1_head1.png", dpi=170)
    plt.close(fig)

    sample_prompt = "The cat sat on the"
    sample_logits, _ = model.forward(ENC.encode(sample_prompt))
    last_logits = sample_logits[-1]
    greedy_id = int(np.argmax(last_logits))
    sampling = {
        "prompt": sample_prompt,
        "greedy": {"id": greedy_id, "text": token_text(greedy_id)},
        "strategies": [
            summarize_sampling(last_logits, temperature=0.1),
            summarize_sampling(last_logits, temperature=1.0),
            summarize_sampling(last_logits, temperature=2.0),
            summarize_sampling(last_logits, temperature=1.0, top_k=20),
            summarize_sampling(last_logits, temperature=1.0, top_p=0.9),
        ],
    }

    ablation_ids = ENC.encode(sample_prompt)
    baseline, base_attn = model.forward(ablation_ids, attention_layer=0, attention_head=0)
    ablations = []
    for name, option in [
        ("remove_sqrt_dk_scale", {"no_scale": True}),
        ("remove_causal_mask", {"no_mask": True}),
        ("remove_residual_additions", {"no_residual": True}),
    ]:
        changed, changed_attn = model.forward(
            ablation_ids, attention_layer=0, attention_head=0, **option
        )
        difference = np.abs(changed - baseline)
        future = np.triu(changed_attn, k=1)
        ablations.append({
            "name": name,
            "full_logits_max_abs_change": float(difference.max()),
            "last_logits_max_abs_change": float(difference[-1].max()),
            "baseline_last_argmax_id": int(baseline[-1].argmax()),
            "changed_last_argmax_id": int(changed[-1].argmax()),
            "baseline_last_argmax_text": token_text(int(baseline[-1].argmax())),
            "changed_last_argmax_text": token_text(int(changed[-1].argmax())),
            "layer1_head1_last_row_entropy_bits": entropy(changed_attn[-1]),
            "layer1_head1_max_future_mass": float(future.sum(axis=-1).max()),
        })

    results = {
        "model": "openai-community/gpt2",
        "revision": "607a30d783dfa663caf39e06633721c8d4cfcd7e",
        "safetensors_sha256": sha256_file(MODEL / "model.safetensors"),
        "versions": {"numpy": np.__version__, "torch": torch.__version__,
                     "transformers": transformers.__version__, "tiktoken": tiktoken.__version__},
        "tokenization": tokenization,
        "toy_bpe": toy_bpe(["banana", "bandana", "banana"]),
        "attention": {
            "prompt": attention_prompt,
            "token_ids": attention_ids,
            "labels": labels,
            "shape": list(attn.shape),
            "row_sums": attn.sum(axis=-1).round(7).tolist(),
            "max_future_mass": float(np.triu(attn, k=1).sum(axis=-1).max()),
            "last_row_entropy_bits": entropy(attn[-1]),
        },
        "sampling": sampling,
        "ablation_prompt": sample_prompt,
        "ablations": ablations,
    }
    (ROOT / "experiment_results.json").write_text(
        json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps({
        "token_counts": [{k: x[k]["count"] for k in ("ko", "en")} for x in tokenization],
        "attention": {"shape": results["attention"]["shape"],
                      "max_future_mass": results["attention"]["max_future_mass"]},
        "sampling_greedy": sampling["greedy"],
        "ablations": ablations,
    }, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
