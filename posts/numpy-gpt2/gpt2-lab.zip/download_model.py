"""Download only the public GPT-2 small files used by this tutorial."""

import hashlib
from pathlib import Path

from huggingface_hub import snapshot_download


ROOT = Path(__file__).resolve().parent
REVISION = "607a30d783dfa663caf39e06633721c8d4cfcd7e"
EXPECTED_SHA256 = "248dfc3911869ec493c76e65bf2fcf7f615828b0254c12b473182f0f81d3a707"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    path = Path(snapshot_download(
        repo_id="openai-community/gpt2",
        revision=REVISION,
        allow_patterns=["config.json", "generation_config.json", "model.safetensors",
                        "tokenizer.json", "tokenizer_config.json", "vocab.json", "merges.txt"],
        local_dir=ROOT / "model",
    ))
    actual = sha256_file(path / "model.safetensors")
    if actual != EXPECTED_SHA256:
        raise RuntimeError(f"checkpoint hash mismatch: {actual}")
    print(f"Downloaded GPT-2 small at {REVISION}; SHA-256 verified: {actual}")


if __name__ == "__main__":
    main()
