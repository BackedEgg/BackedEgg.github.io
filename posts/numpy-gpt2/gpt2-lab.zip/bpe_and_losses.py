"""GPT-2 byte BPE for ordinary text, plus measured and illustrative losses."""
import json
from pathlib import Path

import numpy as np
import regex
import tiktoken

from gpt2_numpy import GPT2NumPy

ROOT = Path(__file__).resolve().parent
MODEL = ROOT / "model"
PATTERN = regex.compile(r"'s|'t|'re|'ve|'m|'ll|'d| ?\p{L}+| ?\p{N}+| ?[^\s\p{L}\p{N}]+|\s+(?!\S)|\s+")


class ByteBPE:
    def __init__(self, folder):
        self.vocab = json.loads((folder / "vocab.json").read_text(encoding="utf8"))
        lines = (folder / "merges.txt").read_text(encoding="utf8").splitlines()[1:]
        self.ranks = {tuple(line.split()): rank for rank, line in enumerate(lines) if line}
        printable = list(range(33, 127)) + list(range(161, 173)) + list(range(174, 256))
        self.symbol = {b: chr(b) for b in printable}
        for i, b in enumerate(b for b in range(256) if b not in printable):
            self.symbol[b] = chr(256 + i)

    def encode(self, text):
        ids = []
        for chunk in PATTERN.findall(text):
            pieces = [self.symbol[b] for b in chunk.encode("utf8")]
            while len(pieces) > 1:
                pairs = set(zip(pieces, pieces[1:]))
                known = pairs.intersection(self.ranks)
                if not known:
                    break
                left, right = min(known, key=self.ranks.get)
                merged = []
                i = 0
                while i < len(pieces):
                    if pieces[i:i + 2] == [left, right]:
                        merged.append(left + right)
                        i += 2
                    else:
                        merged.append(pieces[i])
                        i += 1
                pieces = merged
            ids.extend(self.vocab[s] for s in pieces)
        return ids


def main():
    custom = ByteBPE(MODEL)
    ref = tiktoken.get_encoding("gpt2")
    texts = ["나는 오늘 학교에 간다.", "I go to school today.", "고양이가 창문 옆에 앉아 있다.",
             "A cat is sitting by the window.", "The cat sat on the floor.", "I'm here!  🐈\n"]
    for text in texts:
        assert custom.encode(text) == ref.encode(text)
    ids = custom.encode(texts[4])
    model = GPT2NumPy(MODEL)
    scores, _ = model.forward(ids[:-1])
    scores = scores.astype(np.float64)
    log_probs = scores - np.logaddexp.reduce(scores, axis=-1, keepdims=True)
    nll = -log_probs[np.arange(len(ids)-1), ids[1:]]
    # Prompt is "The cat sat on the"; supervised response is " floor."
    start = len(custom.encode("The cat sat on the")) - 1
    assert ids[start+1:] == custom.encode(" floor.")
    rm_loss = np.logaddexp(0, -(2.0 - 1.0))
    ratio, advantage, epsilon = 1.3, 1.0, 0.2
    policy_loss = -min(ratio * advantage, np.clip(ratio, 1-epsilon, 1+epsilon) * advantage)
    beta = 0.1
    margin = np.log(0.30/0.20) - np.log(0.10/0.20)
    result = dict(bpe_matches=len(texts), text=texts[4],
                  targets=[ref.decode([i]) for i in ids[1:]], nll=nll.tolist(),
                  mean_ce=float(nll.mean()), response_ce=float(nll[start:].mean()),
                  toy_reward_model=float(rm_loss), toy_ppo_policy=float(policy_loss),
                  toy_dpo=float(np.logaddexp(0, -beta*margin)))
    output = json.dumps(result, ensure_ascii=False, indent=2)
    (ROOT / "loss_results.json").write_text(output, encoding="utf8")
    print(output)


if __name__ == "__main__":
    main()
